import React, {Component} from 'react';

class R023_PropsNode extends Component {
  render() {
    return (
      <React.Fragment>
        <p>P TAG</p>
        <span>SPAN TAG</span>
      </React.Fragment>
    )
  }
}

export default R032_Fragments;